import pygame
from graphics import WINWIDTH
from graphics import WINHEIGHT

emerald = False
quest = False
emeraldpng = pygame.image.load("unsorted/emerald.png")
fade = pygame.image.load("unsorted/fade.png")

wizardidle = [
            [0, 0, 86, 86, 8, (255, 255, 255)],
            [1, 0, 86, 86, 8, (255, 255, 255)],
            [2, 0, 86, 86, 8, (255, 255, 255)],
            [3, 0, 86, 86, 8, (255, 255, 255)],
            [4, 0, 86, 86, 8, (255, 255, 255)],
            [5, 0, 86, 86, 8, (255, 255, 255)],
            [4, 0, 86, 86, 8, (255, 255, 255)],
            [3, 0, 86, 86, 8, (255, 255, 255)],
            [2, 0, 86, 86, 8, (255, 255, 255)],
            [1, 0, 86, 86, 8, (255, 255, 255)],
            ]

manidle = [
            [0, 0, 46, 84, 8, (255, 255, 255)],
            [1, 0, 46, 84, 8, (255, 255, 255)],
            [2, 0, 46, 84, 8, (255, 255, 255)],
            [3, 0, 46, 84, 8, (255, 255, 255)],
            [4, 0, 46, 84, 8, (255, 255, 255)],
            [5, 0, 46, 84, 8, (255, 255, 255)],
]

bossidle = [
            [0, 0, 61, 117, 8, (255, 255, 255)],
            [1, 0, 61, 117, 8, (255, 255, 255)],
            [2, 0, 61, 117, 8, (255, 255, 255)],
            [3, 0, 61, 117, 8, (255, 255, 255)],
            [4, 0, 61, 117, 8, (255, 255, 255)],
            [5, 0, 61, 117, 8, (255, 255, 255)],
            [6, 0, 61, 117, 8, (255, 255, 255)],
            [7, 0, 61, 117, 8, (255, 255, 255)],
            ]

wizardtext = ["I seem to have lost my magic emerald....","Traveler, if you would bring me my emerald, I shall grant you strength"]
wizardtext2 = ["You found my emerald!","Take these bombs. They will come in handy!"]
choicetext = ["You can now choose. Go left to help your vitality, or go right to better your armory","I shall wait here for you"]
choicetext2 = ["A fine choice","Now fight warrior!"]

bosstext1 = ["test","test"]
bosstext2 = ["test","test"]
bosstext3 = ["test","test"]
bosstext4 = ["test","test"]

heart = "unsorted/heart.png"
blackheart = "unsorted/blackheart.png"

# Alla object på våra maps och vart dom ligger plaserade
# Först bild, sen tuple med placering på bilden där 0.5 är mitten och 1 är längst bort
# Exempel:
#startroomobjects = ["wizardpath.png",(0,0.5)]


#forestfadetext = ["Detta är en skog. Skogibogitog","Oj ett träd","Shit en kebab!"]
startfadetext = []
##wizardfadetext = []
#combatfadetext = []

# Enemies:
#Picture, HP, DMG, Name, kill function number
swordskeleton1 = [pygame.image.load("enemies/swordskeleton.png"),15,2,"Sword wielding skeleton",1000]
swordskeleton2 = [pygame.image.load("enemies/swordskeleton.png"),15,2,"Sword wielding skeleton",2000]
ballskeleton = [pygame.image.load("enemies/ballskeleton.png"),15,4,"Spiked ball wielding skeleton",3000]
shieldskeleton1 = [pygame.image.load("enemies/shieldskeleton.png"),20,3,"Shield wielding skeleton",4000]
shieldskeleton2 = [pygame.image.load("enemies/shieldskeleton.png"),20,3,"Shield wielding skeleton",5000]
wizardenemy = [pygame.image.load("enemies/shieldskeleton.png"),0,0,"Shield wielding skeleton",6000]
wizard2 = [pygame.image.load("enemies/shieldskeleton.png"),0,0,"Shield wielding skeleton",7000]
hproom = [pygame.image.load("enemies/shieldskeleton.png"),0,0,"Shield wielding skeleton",10000]
dmgroom = [pygame.image.load("enemies/shieldskeleton.png"),0,0,"Shield wielding skeleton",11000]

boss1 = [pygame.image.load("enemies/boss1.png"),1,1,"Shield wielding skeleton",12000]
boss2 = [pygame.image.load("enemies/boss2.png"),1,1,"Shield wielding skeleton",13000]
boss3 = [pygame.image.load("enemies/boss3.png"),1,1,"Shield wielding skeleton",14000]
boss4 = [pygame.image.load("enemies/boss4.png"),1,1,"Shield wielding skeleton",15000]

def kill(number):
        global emerald
        global quest
        if number == 1000:
            room3[9] = "path"
        if number == 2000:
            room5[9] = "path"
        if number == 3000:
            room8[9] = "path"
        if number == 4000:
            room12[9] = "path"
        if number == 5000:
            room13[9] = "path"
        if number == 6000:
                if emerald:
                        for x in range(len(room9)):
                                room9[x] = lastroom9[x]
                                emerald = False
                                getitem(elthezarsbomb)
                                getitem(elthezarsbomb)
                else:
                        for x in range(len(room15)):
                                room15[x] = emeraldroom15[x]
                        for x in range(len(room9)):
                                room9[x] = newroom9[x]
                        quest = True
        if number == 7000:
                if quest:
                        for x in range(len(room15)):
                                room15[x] = clearroom15[x]
                                room9[x] = lastcombatroom9[x]
                        emerald = True
        if number == 10000:
                healthroom[9] = "path"
                healthroom[11] = healthroomentertext
                choice[2] = False
                choice[3] = True
                choice[12] = choicetext2
                choice[11] = choicefadetext2
                getitem(healthpotion)
                getitem(healthvial)
        if number == 11000:
                choice[4] = False
                choice[3] = True
                choice[12] = choicetext2
                choice[11] = choicefadetext2
                weaponroom[9] = "path"
                weaponroom[11] = weaponroomentertext
                getitem(sword)
                getitem(platearmor)
        if number == 12000:
            boss1[9] = "path"
        if number == 13000:
            boss2[9] = "path"
        if number == 14000:
            boss3[9] = "path"
        if number == 15000:
            boss4[9] = "path"

def getitem(pickedupitem):
    global keystart
    for y in range (3):
        for x in range (4):
            i=listinlist(listinlist(inventorylist,y),x)
            if i[1] == "empty" and i[2] != pickedupitem[1]:
                changeslot(y,x,pickedupitem)
                return None
            elif i[2] == pickedupitem[1]:
                i[5] = i[5] + 1
                changeslot(y,x,tail(i))
                return None

def tail(list):
    b = []
    for x in range (len(list)):
        b.append(list[x])
    b.pop(0)
    return b

# 0-Bild, Kan gå 1-Up, 2-höger, 3-ner, 4-vänster, 5,6,7,8-namn på hållen, 9-vilken typ av rum, 20-bild för fade in, 11-text för fade in,
# 12-object som ska printas på rummet (när rummet är path), 13-monstret om combat, 13-text till person om rummet är textbox,
# 14-idle bild för person i textbox, 15-idle lista med hur idle ser ut

room1fadetext = []
room1objects = ["unsorted/player.gif",(0.5,0.5)]
room1 = [pygame.image.load("topdown/top1.jpg"),False,True,True,False,"","","","","path",pygame.image.load("loading/1.png"),room1fadetext,room1objects]

startroom = []

room2fadetext = []
room2objects = ["unsorted/player.gif",(0.5,0.5)]
room2 = [pygame.image.load("topdown/top2.jpg"),False,True,True,True,"","","","","path",pygame.image.load("loading/2.png"),room2fadetext,room2objects]

room3fadetext = []
room3objects = ["unsorted/player.gif",(0.5,0.5)]
room3 = [pygame.image.load("topdown/top3.jpg"),False,False,True,True,"","","","","combat",pygame.image.load("loading/3.png"),room3fadetext,room3objects,swordskeleton1]

room4fadetext = []
room4objects = ["unsorted/player.gif",(0.5,0.5)]
room4 = [pygame.image.load("topdown/top4.jpg"),True,True,True,False,"","","","","path",pygame.image.load("loading/4.png"),room4fadetext,room4objects]

room5fadetext = []
room5objects = ["unsorted/player.gif",(0.5,0.5)]
room5 = [pygame.image.load("topdown/top5.jpg"),True,True,True,True,"","","","","combat",pygame.image.load("loading/5.png"),room5fadetext,room5objects,swordskeleton2]

room6fadetext = []
room6objects = ["unsorted/player.gif",(0.5,0.5)]
room6 = [pygame.image.load("topdown/top6.jpg"),True,False,True,True,"","","","","path",pygame.image.load("loading/6.png"),room6fadetext,room6objects]

room7fadetext = []
room7objects = ["unsorted/player.gif",(0.5,0.5)]
room7 = [pygame.image.load("topdown/top7.jpg"),True,True,True,False,"","","","","path",pygame.image.load("loading/7.png"),room7fadetext,room7objects]

room8fadetext = []
room8objects = ["unsorted/player.gif",(0.5,0.5)]
room8 = [pygame.image.load("topdown/top8.jpg"),True,True,True,True,"","","","","combat",pygame.image.load("loading/8.png"),room8fadetext,room8objects,ballskeleton]

room9fadetext = ["You met a very old wizard"]
room9fadetext2 = ["You return to the wizard"]
room9objects = []
room9 = [pygame.image.load("topdown/top9.jpg"),True,False,True,True,"","","","","combat",pygame.image.load("loading/9.png"),room9fadetext,room9objects,wizardenemy,wizardidle]
newroom9 = [pygame.image.load("topdown/top9.jpg"),True,False,True,True,"","","","","textbox",pygame.image.load("loading/9.png"),room9fadetext,wizardtext,"unsorted/idle.png",wizardidle]
lastcombatroom9 = [pygame.image.load("topdown/top9.jpg"),True,False,True,True,"","","","","combat",pygame.image.load("loading/9.png"),room9fadetext2,room9objects,wizardenemy,wizardidle]
lastroom9 = [pygame.image.load("topdown/top9.jpg"),True,False,True,True,"","","","","textbox",pygame.image.load("loading/9.png"),room9fadetext,wizardtext2,"unsorted/idle.png",wizardidle]

room10fadetext = []
room10objects = ["unsorted/player.gif",(0.5,0.5)]
room10 = [pygame.image.load("topdown/top10.jpg"),True,True,True,False,"","","","","path",pygame.image.load("loading/10.png"),room10fadetext,room10objects]

room11fadetext = []
room11objects = ["unsorted/player.gif",(0.5,0.5)]
room11 = [pygame.image.load("topdown/top11.jpg"),True,True,True,True,"","","","","path",pygame.image.load("loading/11.png"),room11fadetext,room11objects]

room12fadetext = []
room12objects = ["unsorted/player.gif",(0.5,0.5)]
room12 = [pygame.image.load("topdown/top12.jpg"),True,False,True,True,"","","","","combat",pygame.image.load("loading/12.png"),room12fadetext,room12objects,shieldskeleton1]

room13fadetext = []
room13objects = ["unsorted/player.gif",(0.5,0.5)]
room13 = [pygame.image.load("topdown/top13.jpg"),True,True,True,False,"","","","","combat",pygame.image.load("loading/13.png"),room13fadetext,room13objects,shieldskeleton1]

room14fadetext = []
room14objects = ["unsorted/player.gif",(0.5,0.5)]
room14 = [pygame.image.load("topdown/top14.jpg"),True,True,True,True,"","","","","path",pygame.image.load("loading/14.png"),room14fadetext,room14objects]

###################
# quest room

room15fadetext = [] # No emerald room
room15objects = ["unsorted/player.gif",(0.5,0.5)]
room15 = [pygame.image.load("topdown/top15.jpg"),True,False,True,True,"","","","","path",pygame.image.load("loading/15.png"),room15fadetext,room15objects,wizard2]

clearroom15fadetext = [] # No emerald room
clearroom15 = [pygame.image.load("topdown/top15.jpg"),True,False,True,True,"","","","","path",pygame.image.load("loading/15.png"),clearroom15fadetext,room15objects,wizard2]

emeraldroom15fadetext = ["You found a magic emerald inside this room. You put it into your inventory"] # Enter restroom text
emeraldroom15 = [pygame.image.load("topdown/top15.jpg"),True,False,True,True,"","","","","combat",pygame.image.load("loading/15.png"),emeraldroom15fadetext,room15objects,wizard2]

# quest room
###################

room16fadetext = []
room16objects = ["unsorted/player.gif",(0.5,0.5)]
room16 = [pygame.image.load("topdown/top16.jpg"),True,True,False,False,"","","","","path",pygame.image.load("loading/16.png"),room16fadetext,room16objects]

room17fadetext = []
room17objects = ["unsorted/player.gif",(0.5,0.5)]
room17 = [pygame.image.load("topdown/top17.jpg"),True,True,True,True,"","","","","path",pygame.image.load("loading/17.png"),room17fadetext,room17objects]

room18fadetext = []
room18objects = ["unsorted/player.gif",(0.5,0.5)]
room18 = [pygame.image.load("topdown/top18.jpg"),True,False,False,True,"","","","","path",pygame.image.load("loading/18.png"),room18fadetext,room18objects]

room19 = []
room20 = []
room21 = []

healthroomfadetext = ["You found a health potion and a health vial!"]
healthroomentertext = []
healthroomobjects = []
healthroom = [pygame.image.load("unsorted/healthroom.jpg"),False,True,False,False,"","","","","combat",pygame.image.load("unsorted/healthroom.jpg"),healthroomfadetext,healthroomobjects,hproom]

weaponroomfadetext = ["You found a sword and full plate armor!"]
weaponroomentertext = []
weaponroomobjects = []
weaponroom = [pygame.image.load("unsorted/weaponroom.jpg"),False,False,False,True,"","","","","combat",pygame.image.load("unsorted/weaponroom.jpg"),weaponroomfadetext,weaponroomobjects,dmgroom]

choicefadetext = ["A strange man is inside this room"]
choicefadetext2 = []
choice = [pygame.image.load("topdown/top5.jpg"),True,True,False,True,"","","","","textbox",pygame.image.load("loading/5.png"),choicefadetext,choicetext,"unsorted/idle2.png",manidle]

fakeroom = []

bosstalkfadetext1 = []
bosstalk1 = [pygame.image.load("loading/boss1.png"),False,False,True,False,"","","","","textbox",pygame.image.load("loading/boss1.png"),bosstalkfadetext1,bosstext1,"unsorted/bossidle.png",bossidle]

boss1fadetext = []
boss1objects = []
boss1 = [pygame.image.load("loading/boss1.png"),False,False,True,False,"","","","","combat",pygame.image.load("loading/boss1.png"),boss1fadetext,boss1objects,boss1]

bosstalkfadetext2 = []
bosstalk2 = [pygame.image.load("loading/boss2.png"),False,False,True,False,"","","","","textbox",pygame.image.load("loading/boss2.png"),bosstalkfadetext2,bosstext2,"unsorted/bossidle.png",bossidle]

boss2fadetext = []
boss2objects = []
boss2 = [pygame.image.load("loading/boss2.png"),False,False,True,False,"","","","","combat",pygame.image.load("loading/boss2.png"),boss2fadetext,boss2objects,boss2]

bosstalkfadetext3 = []
bosstalk3 = [pygame.image.load("loading/boss3.png"),False,False,True,False,"","","","","textbox",pygame.image.load("loading/boss3.png"),bosstalkfadetext3,bosstext3,"unsorted/bossidle.png",bossidle]

boss3fadetext = []
boss3objects = []
boss3 = [pygame.image.load("loading/boss3.png"),False,False,True,False,"","","","","combat",pygame.image.load("loading/boss3.png"),boss3fadetext,boss3objects,boss3]

bosstalkfadetext4 = []
bosstalk4 = [pygame.image.load("loading/boss4.png"),False,False,True,False,"","","","","textbox",pygame.image.load("loading/boss4.png"),bosstalkfadetext4,bosstext4,"unsorted/bossidle.png",bossidle]

boss4fadetext = []
boss4objects = []
boss4 = [pygame.image.load("loading/boss4.png"),False,False,True,False,"","","","","combat",pygame.image.load("loading/boss4.png"),boss4fadetext,boss4objects,boss4]

# Kartan
map = [[startroom],
      [room1,room2,room3],
      [room4,room5,room6],
      [room7,room8,room9],
      [room10,room11,room12],
      [room13,room14,room15],
      [room16,room17,room18],
      [healthroom,choice,weaponroom],
      [fakeroom,bosstalk1,fakeroom],
      [fakeroom,boss1,fakeroom],
      [fakeroom,bosstalk2,fakeroom],
      [fakeroom,boss2,fakeroom],
      [fakeroom,bosstalk3,fakeroom],
      [fakeroom,boss3,fakeroom],
      [fakeroom,bosstalk4,fakeroom],
      [fakeroom,boss4,fakeroom],]
mapcheckpoint = []

def save_checkpoint():
        global mapcheckpoint
        mapcheckpoint = list(map)
        global inventorylistcheckpoint
        inventorylistcheckpoint = list(inventorylist)

        global slot1copy
        global slot2copy
        global slot3copy
        global slot4copy
        global slot5copy
        global slot6copy
        global slot7copy
        global slot8copy
        global slot9copy
        global slot10copy
        global slot11copy
        global slot12copy
        for x in range(6):
                slot1copy[x] = slot1[x]
        for x in range(6):
                slot2copy[x] = slot2[x]
        for x in range(6):
                slot3copy[x] = slot3[x]
        for x in range(6):
                slot4copy[x] = slot4[x]
        for x in range(6):
                slot5copy[x] = slot5[x]
        for x in range(6):
                slot6copy[x] = slot6[x]
        for x in range(6):
                slot7copy[x] = slot7[x]
        for x in range(6):
                slot8copy[x] = slot8[x]
        for x in range(6):
                slot9copy[x] = slot9[x]
        for x in range(6):
                slot10copy[x] = slot10[x]
        for x in range(6):
                slot11copy[x] = slot11[x]
        for x in range(6):
                slot12copy[x] = slot12[x]

def load_checkpoint():
        global map
        global inventorylist
        map = list(mapcheckpoint)
        inventorylist = list(inventorylistcheckpoint)

        global slot1
        global slot2
        global slot3
        global slot4
        global slot5
        global slot6
        global slot7
        global slot8
        global slot9
        global slot10
        global slot11
        global slot12
        for x in range(6):
                slot1[x] = slot1copy[x]
        for x in range(6):
                slot2[x] = slot2copy[x]
        for x in range(6):
                slot3[x] = slot3copy[x]
        for x in range(6):
                slot4[x] = slot4copy[x]
        for x in range(6):
                slot5[x] = slot5copy[x]
        for x in range(6):
                slot6[x] = slot6copy[x]
        for x in range(6):
                slot7[x] = slot7copy[x]
        for x in range(6):
                slot8[x] = slot8copy[x]
        for x in range(6):
                slot9[x] = slot9copy[x]
        for x in range(6):
                slot10[x] = slot10copy[x]
        for x in range(6):
                slot11[x] = slot11copy[x]
        for x in range(6):
                slot12[x] = slot12copy[x]

########################################################################################

position1=(WINWIDTH*0.07,WINHEIGHT*0.19)
position2=(WINWIDTH*0.192,WINHEIGHT*0.19)
position3=(WINWIDTH*0.315,WINHEIGHT*0.19)
position4=(WINWIDTH*0.44,WINHEIGHT*0.19)

position5=(WINWIDTH*0.07,WINHEIGHT*0.35)
position6=(WINWIDTH*0.192,WINHEIGHT*0.35)
position7=(WINWIDTH*0.315,WINHEIGHT*0.35)
position8=(WINWIDTH*0.44,WINHEIGHT*0.35)

position9=(WINWIDTH*0.07,WINHEIGHT*0.51)
position10=(WINWIDTH*0.192,WINHEIGHT*0.51)
position11=(WINWIDTH*0.315,WINHEIGHT*0.51)
position12=(WINWIDTH*0.44,WINHEIGHT*0.51)

dagger=[2,"dagger", pygame.image.load("inventory/dagger.png"), "nonconsumable",1]
sword=[5, "sword", pygame.image.load("inventory/sword.png"), "nonconsumable",1]
axe=[4, "axe", pygame.image.load("inventory/axe.png"), "nonconsumable",1]
pickaxe=[3, "pickaxe", pygame.image.load("inventory/pickaxe.png"), "nonconsumable",1]
chainmail=[10, "chainmail", pygame.image.load("inventory/chainmail.png"),"nonconsumable",1]
splint=[20, "splint", pygame.image.load("inventory/splint.png"),"nonconsumable",1]
halfplatearmor=[30,"half plate armor",pygame.image.load("inventory/halfplatearmor.png"), "nonconsumable",1]
platearmor=[40, "plate armor",pygame.image.load("inventory/platearmor.png"), "nonconsumable",1]
elthezarsbomb=[6, "elthezars bomb",pygame.image.load("inventory/elthezarsbomb.png"),"consumable",1]
healthpotion=[8, "health potion",pygame.image.load("inventory/healthpotion.png"), "consumable",1]
orange=[2, "orange",pygame.image.load("inventory/orange.png"), "consumable",1]
healthvial=[5,"health vial", pygame.image.load("inventory/healthvial.png"),"consumable",1]
empty="empty"
#[position, value,name, image, consumable/nonconsumable, amount]
slot1=[position1,2,"dagger", pygame.image.load("inventory/dagger.png"), "nonconsumable",1]
slot2=[position2,10, "chainmail", pygame.image.load("inventory/chainmail.png"),"nonconsumable",1]
slot3=[position3,2, "orange",pygame.image.load("inventory/orange.png"), "consumable",2]
slot4=[position4,empty,empty,empty,empty,0]

slot5=[position5,empty,empty,empty,empty,0]
slot6=[position6,empty,empty,empty,empty,0]
slot7=[position7,empty,empty,empty,empty,0]
slot8=[position8,empty,empty,empty,empty,0]

slot9=[position9,empty,empty,empty,empty,0]
slot10=[position10,empty,empty,empty,empty,0]
slot11=[position11,empty,empty,empty,empty,0]
slot12=[position12,empty,empty,empty,empty,0]

slot1copy=[position1,empty,empty,empty,empty,0]
slot2copy=[position2,empty,empty,empty,empty,0]
slot3copy=[position3,empty,empty,empty,empty,0]
slot4copy=[position4,empty,empty,empty,empty,0]

slot5copy=[position5,empty,empty,empty,empty,0]
slot6copy=[position6,empty,empty,empty,empty,0]
slot7copy=[position7,empty,empty,empty,empty,0]
slot8copy=[position8,empty,empty,empty,empty,0]

slot9copy=[position9,empty,empty,empty,empty,0]
slot10copy=[position10,empty,empty,empty,empty,0]
slot11copy=[position11,empty,empty,empty,empty,0]
slot12copy=[position12,empty,empty,empty,empty,0]

def head(list):
       a = [""]
       a[0] = list[0]
       return a

def listinlist(list,index):
    return list[index]

def changeslot(invy,invx,change):
    global slot1
    global slot2
    global slot3
    global slot4
    global slot5
    global slot6
    global slot7
    global slot8
    global slot9
    global slot10
    global slot11
    global slot12
    if invy == 0 and invx == 0:
        for x in range(len(change)):
            slot1[x+1] = change[x]
    if invy == 0 and invx == 1:
        for x in range(len(change)):
            slot2[x+1] = change[x]
    if invy == 0 and invx == 2:
        for x in range(len(change)):
            slot3[x+1] = change[x]
    if invy == 0 and invx == 3:
         for x in range(len(change)):
            slot4[x+1] = change[x]
    if invy == 1 and invx == 0:
         for x in range(len(change)):
            slot5[x+1] = change[x]
    if invy == 1 and invx == 1:
         for x in range(len(change)):
            slot6[x+1] = change[x]
    if invy == 1 and invx == 2:
         for x in range(len(change)):
            slot7[x+1] = change[x]
    if invy == 1 and invx == 3:
         for x in range(len(change)):
            slot8[x+1] = change[x]
    if invy == 2 and invx == 0:
         for x in range(len(change)):
            slot9[x+1] = change[x]
    if invy == 2 and invx == 1:
         for x in range(len(change)):
            slot10[x+1] = change[x]
    if invy == 2 and invx == 2:
         for x in range(len(change)):
            slot11[x+1] = change[x]
    if invy == 2 and invx == 3:
         for x in range(len(change)):
            slot12[x+1] = change[x]

inventorylist = [[slot1,slot2, slot3, slot4],
                 [slot5,slot6,slot7,slot8],
                 [slot9,slot10,slot11,slot12]]
inventorylistcheckpoint = []

########################################################################################
